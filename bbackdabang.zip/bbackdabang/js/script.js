$(function(){
    //header navigation
    let navBg = $('.sub-bg');
    let nav = $('.nav');
    let one_li = $('.nav>ul>li')
    let two_ul = $('.nav>ul>li>ul');

    nav.hover(
        function(){
            navBg.addClass('on');

        }, function(){
            navBg.removeClass('on');
        },
        one_li.hover(
            function(){
                $(this).find('ul').slideDown(400)
            }, function(){
                $(this).find('ul').slideUp(400);
            }
        )
    )

    //main-swiper
    var swiper = new Swiper(".mySwiper", {
      pagination: {
        el: ".swiper-pagination",
      },
    });
})